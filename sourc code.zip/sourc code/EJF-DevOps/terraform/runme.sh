#!/bin/bash
export mots_id=$(awk '/mots_id/ {print $3;}' terraform.tfvars | tr -d '"' | tr -d '\040\011\012\015')
export region=$(awk '/region/ {print $3;}' terraform.tfvars | tr -d '"' | tr -d '\040\011\012\015')
export backend_resource_group_name=$mots_id-$region-devops-rg
export backend_storage_account_name="${mots_id}devopsstdgatt001"
export backend_container_name="devopstfstate"

terraform init
terraform apply -auto-approve

key=$(az storage account keys list -g $backend_resource_group_name -n $backend_storage_account_name --query [0].value -o tsv)
az storage account update --default-action Allow --name $backend_storage_account_name --resource-group $backend_resource_group_name &
sleep 30
az storage container create --name $backend_container_name --account-name $backend_storage_account_name &
sleep 30
az storage blob upload --account-name $backend_storage_account_name --account-key $key --container-name $backend_container_name --file terraform.tfstate --name terraform.tfstate
az storage account update --default-action Deny --name $backend_storage_account_name --resource-group $backend_resource_group_name