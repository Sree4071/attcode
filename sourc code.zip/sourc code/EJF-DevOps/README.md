[[_TOC_]]

# Azure DevOps Onboarding Overview

This document will describe how to deploy the base infrastructure that is needed in order to successfully start deploying resources to Azure.

# Prerequisites

In order to follow this guide, the following prerequisites must be met:

- If using a VP Tower Bastion, the user must have the resource ID of the PLS in the Bastion network
- If using a regional Bastion, the user must know which region they need to connect to (East US 2 or West US 2)
- The user must submit a new Regional Bastion access request [form](https://workspace.web.att.com/sites/pubcldbastion/SitePages/Home.aspx) to get auto-approval for the Regional Bastion PE request
- The Azure DevOps project must already exist
- The user must have sufficient permissions in Azure DevOps to create a an agent pool

## Azure DevOps Onboarding Steps

### Request Auto-approval for Bastion Private Endpoint Connectivity

Please go to this [link](https://workspace.web.att.com/sites/pubcldbastion/SitePages/Home.aspx) and click on "Regional Bastion Access Request." Fill out the form with the necessary information and submit for auto-approval.
>Note: If this is not setup prior to running the scripts, you will have to scale down your VMSS to 0 and scale out to your desired number of instances once the request is approved.

### Create Agent Pool

In order to run pipelines to deploy resources into Azure, an agent pool comprised of self-hosted, private agents will need to be configured. Later on, a Virtual Machine Scale Set will be deployed and connected to this agent pool. You can then reference the name of the agent pool within your pipelines. To create an agent pool, do the following:

1. Login to Azure DevOps and navigate to the appropriate organization.
1. Click on **Organization Settings** and **Agent Pools**.
1. Click on **Add Pool** at the top right corner.
1. Select the Pool Type to be **Self-Hosted**.
1. Name the agent pool using this format: "<MOTS ID>agents"
1. Select "Grant access permissions to all pipelines"
1. Un-select "Auto-provision this agent pool in all projects"

[Creating Agent Pools - Azure DevOps](https://docs.microsoft.com/en-us/azure/devops/pipelines/agents/pools-queues?view=azure-devops&tabs=yaml%2Cbrowser#creating-agent-pools)


### Setup Maintenance Jobs

To ensure the agents do not run out of space with data from previous runs, you will need to manually setup maintenance jobs as well. These jobs will run at a specified date and time that you select. To setup maintenance jobs, do the following:

1. Login to Azure DevOps and navigate to the appropriate organization.
1. Click on **Organization Settings** and **Agent Pools**.
1. Click on the agent pool you created above and click on **Settings**.
1. Toggle on the **Enable agent maintenance job**.
1. (The settings are up to the application team) We recommend changing the **Days to keep unused working directories** to 14 to ensure the agents do not run out of space. Everything else can remain the default value.
1. Under **Scheduling**, pick a day and time that will not interview with the application team's work.

### Generate Azure DevOps Personal Access Token

Personal Access Tokens (PAT) are alternate passwords that can be used to authenticate into Azure DevOps. You will  need a PAT for cloning the repo as well as creating an agent pool and registering your agents that are created in the Terraform script (two separate PATs are needed). To create that PAT, ensure you have permissions (use the same account that created the agent pool) and do the following:

1. Sign into Azure DevOps and click on the application organization.
1. From your home page, open your user settings from the top right corner by your avatar, and then select **Personal Access Tokens**.
1. Click **+ New Token**.
1. Name your token, select your organization under Organization, and then choose a lifespan for your token.
1. Under **Scopes**, check **Read** and **Manage** under **Agent Pools**. This will allow you to pass the PAT into the Terraform script and register agents.
1. Click **Create**.
1. **Be sure to copy the token at this time because you will not be able to see it again!**
1. Repeat these steps for the PAT needed to clone the repo. Note: go to the shared organization and only check **Read** under **Code**. Use this PAT when cloning the repo.

> Please note that the PAT will expire after a year. At this point, your agents will no longer be able to communicate with ADO, and they will appear "offline." To remedy this, the owner of the PAT can edit it and extend the expiration date. If the owner no longer has access, someone with the proper ADO permissions (see above) can generate another PAT and update the terraform.tfvars file and rerun the script. The tfstate file is currently stored in a container within the storage account. Just upload this file to your CloudShell and run the script. Terraform will detect the change and update the PAT accordingly. 

[Create a Personal Access Token - Azure DevOps](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=preview-page#create-personal-access-tokens-to-authenticate-access)
> Please note that the PAT will expire as described [here](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/admin-revoke-user-pats?view=azure-devops#personal-access-token-expiration)
### Run Terraform Script to Provision the Base Infrastructure

The infrastructure described in the Application DevOps Services Design section of this document can be deployed using a Terraform script found in [this repo](https://dev.azure.com/ATTDevOps/ATT%20Cloud/_git/att-onboarding-devops-services). To run the script, please do the following:

1. Go to the repo above, click "Clone" and copy the URL and generate Git credentials.
1. Login to [Azure Cloud Shell](https://www.shell.azure.com)
1. Navigate to your desired directory and type "git clone <URL from above>."
1. Navigate to the Terraform directory.
1. Open the editor for easier navigation between files.
1. Open "terraform.tfvars" and edit the variables accordingly. Note that the agent_pool variable must match the name of the agent pool you create. The PAT is also case sensitive. You must also enter the **entire** PLS resource ID for which your subscription has been onboarded to.
1. If you need an ACR, set the deploy_acr variable to true in terraform.tfvars. **Save the file**.
1. If using a non-regional Bastion, go to the private endpoint for Bastion (pe2) in main.tf and hardcode your PLS resource ID in the "resource_id" variable.
1. In the command prompt, type the following:

```
./runme.sh
```
> Please note that the script creates a Managed Service Identity. Particularly, a [System-Assigned Identity](https://docs.microsoft.com/en-us/azure/active-directory/managed-identities-azure-resources/overview#managed-identity-types) which exists for the life of the virtual machine scale set.

After the script runs, wait 5 minutes and then ensure the Bastion PE is approved (if not, submit request for approval) and the agents appear in Azure DevOps. Once the Bastion PE is approved, navigate to the VMSS in the portal and scale down the instances to 0 and save. Scale back up to however many instances you need to re-run cloud init.

### Add Role Assignment to the NPRD and PROD Service principal

In order for the service principals to access resources in the NPRD subscription, be sure to add the necessary role for that resource. You will need to add "Reader" access to the Shared Image Gallery, for example. You will also need to grant your service principals "Storage Blob Data Contributor" to the storage account, if the pipeline needs to access it.
