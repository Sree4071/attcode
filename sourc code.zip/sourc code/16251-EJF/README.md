# Table of contents

1. [Overview](#Overview)
    1. [Infrastructure as code](#Infrastructureascode)
    2. [Azure Pipelines](#AzurePipelines)
    2. [Learn Git](#LearnGit)
2. [Updating Application](#UpdatingApplication)
    1. [Pushing Artifacts](#pushingArtifacts)
    2. [Running App Deploy Pipeline](#RunningAppDeployPipeline)
3. [Updating Infrastructure](#UpdatingInfrastructure)
    1. [Changing Infrastructure Code](#ChangingInfrastructureCode)
    2. [Running Infrastructure Pipeline](#RunningInfrastructurePipeline)
4. [Full Pipeline Execution](#FullPipelineExecution)
    1. [Running Full Pipeline](#RunningFullPipeline)
5. [Deploying a new environment](#Deployingnewenvironment)
    1. [Prerequisite](#Prerequisite)
    2. [Creating new infrastructure code](#Creatinginfrastructurecode)
    3. [Manual Steps](#ManualSteps)
6. [Appendix](#Appendix)
    1. [Repository Structure and Summary](#repositorystructure)
    2. [Known Errors](#KnownErrors)
    3. [Accessing Jumpbox via SSH (If applicable)](#AccessJumpbox)
    4. [Debugging Steps](#DebuggingSteps)
7. [Resources](#resources)
8. [FAQ](#FAQ)


# Overview <a name="Overview"></a>
This project contains the infrastructure as code and continuous deployment scripts for deploying your application. All resources created in Azure are managed by Terraform which prevents configuration drift and automates changes for consistency and reliability. As part of the factory migration, your project has access to a non-prod (nprd) and production (prod) subscription which contain your environment resources. NPRD is a replica of PROD that can be used for testing or in any manner that your application team decides. 

## Infrastructure as code <a name="Infrastructureascode"></a>
Infrastructure as Code (IaC) is the management of infrastructure (networks, virtual machines, load balancers, and connection topology) in a descriptive model, using the same versioning as DevOps team uses for source code. Like the principle that the same source code generates the same binary, an IaC model generates the same environment every time it is applied. IaC is a key DevOps practice and is used in conjunction with continuous delivery. [Read more](https://docs.microsoft.com/en-us/azure/devops/learn/what-is-infrastructure-as-code)

## Azure Pipelines <a name="AzurePipelines"></a>
Azure Pipelines automatically builds and tests code projects to make them available to others. It works with just about any language or project type. Azure Pipelines combines continuous integration (CI) and continuous delivery (CD) to constantly and consistently test and build your code and ship it to any target. [Read more](https://docs.microsoft.com/en-us/azure/devops/pipelines/get-started/what-is-azure-pipelines?view=azure-devops)

## Learn Git <a name="LearnGit"></a>
Git is the most commonly used version control system today and is quickly becoming the standard for version control. Git is a distributed version control system, meaning your local copy of code is a complete version control repository. These fully-functional local repositories make it is easy to work offline or remotely. You commit your work locally, and then sync your copy of the repository with the copy on the server. This paradigm differs from centralized version control where clients must synchronize code with a server before creating new versions of code.[Read more](https://docs.microsoft.com/en-us/azure/devops/learn/git/what-is-git)

# Updating Application <a name="UpdatingApplication"></a>
When changes to the application are required, those changes can be pushed to the NPRD and then PROD environments in an automated manner using Azure Pipelines. As part of the factory migration process, you are provided with deployment pipelines and have the ability to create continous integration pipelines. Once configured, these continous integration pipelines can allow the entire process of code change to deployment to be fully automated.

## Pushing Artifacts <a name="pushingArtifacts"></a>
The code or binary files required for your application must be stored in a pre-defined location so that the deployment pipeline can access it to deploy to the environments. 
1. Create compressed files which contains required files following naming convention
2. Upload files into "artifacts" container inside storage acount: "16251deploymentsstatt" in "16251-eastus2-devops-deployments-rg" resource group
   2.1 - webs.zip - Application Binaries
   2.2 - mm243d.zip -On Prem Dir (Containing Connect Direct Secure+ at path mm243d\source\ConnectDirect)
   2.3 - OpenSSL-Win32.zip - For Certificate Convertion
   2.4 - fileServer.zip - For FileShare
   2.5 - vaults.zip - Containing Vaults Files


If the file is large, using AZ Copy for uploading the file will be faster than using the portal: [AZ Copy](https://docs.microsoft.com/en-us/azure/storage/common/storage-use-azcopy-v10)

## Running App Deploy Pipeline <a name="RunningAppDeployPipeline"></a>
The app deploy pipeline will deploy your application
1. Run the AppDeploy pipeline (AppDeploy.Yaml)
2. Verify successful deployment in non-prod environment
3. Approve gate to trigger deployment to prod environment
4. Deployments to Virtual Machine Scale Sets use rolling upgrades, so to check the status of the rolling upgrade, utilize the virtual machine scale set resource in the azure portal. [Read more](https://docs.microsoft.com/en-us/azure/virtual-machine-scale-sets/virtual-machine-scale-sets-upgrade-scale-set)

# Updating infrastructure <a name="UpdatingInfrastructure"></a>
- **Changing the infrastructure can be destructive, ensure you run terraform plan prior to applying the changes in order to understand what changes will be applied to the environment**

Your application infrastructure deployed in Azure is managed using Terraform. To make changes to your infrastructure it will require modifying the code and executing the infrastructure or full pipeline.
## Changing Infrastructure Code <a name="ChangingInfrastructureCode"></a>
Review the terraform code in the repository and make changes are required.
[Terraform on Azure](https://docs.microsoft.com/en-us/azure/developer/terraform/overview)

## Running Infrastructure Pipeline <a name="RunningInfrastructurePipeline"></a>
1. After the changes have been created in a new branch, deploy these changes to a POC environment by manually running the env-infrastructure pipeline and choosing your branch as the source and specifying the correct environment
2. After the POC environment is succesful, open a pull request to the Main branch
2. Once the pull request is completed, the CI deployment to NPRD will begin. Once NPRD is completed, review the changes and approve or reject the deployment to PROD

# Full Pipeline Execution <a name="FullPipelineExecution"></a> 
The full pipeline runs all stages which includes making any infrastructure changes and pushing any application changes. The full pipeline deploys NPRD and then checks for approval prior to running any PROD stages.

## Running Full Pipeline <a name="RunningFullPipeline"></a> 
Running the full pipeline might be required if you want to make changes to infrastructure and the application in a single run instead of individually. To run the full pipeline, simply navigate to Azure Pipelines and execute the pipeline. 

# Deploying a new environment <a name="Deployingnewenvironment"></a> 
Currently the available environments are nprd and prod. If you want to deploy a new environment for dev/test, it can be done in an automated fashion utilizing the same patterns that NPRD and PROD follow. 

## Prerequisite <a name="Prerequisite"></a> 
- If using a new subscription
    - Create service principal and provide appropriate access
    - Onboard subscription to Bastion
- Ensure you are familiar with Terraform and the current patterns being used in your project

## Creating new infrastructure code <a name="Creatinginfrastructurecode"></a> 
Following the same pattern used for NPRD and PROD, create similar configurations for your new environment. Deploy this new environment using the env-infrastructure pipeline and specifying the name of the environment that you want that pipeline to deploy

## Manual Steps <a name="ManualSteps"></a> 
Manual steps once Key Vault is created for each environment 
- Add EJF Connection string secret in Keyvault in below format
  Ex:- EJFConnectionString
- Add EJFHD Connection string secret in Keyvault in below format
  Ex:- EJFHDConnectionString
- Add ABCpdfLicense string secret in Keyvault in below format
  Ex:- ABCpdfLicense
- Add SSL cert password secret in Keyvault in below format
  Ex:- certpassword
- Add mechIdPassword for app server secret in Keyvault in below format
  Ex:- mechIdPassword
- Add tnsDbEntry secret for tnsnames.ora file in Keyvault in below format
  Ex:- tnsDbEntry
- Add HTTPS certificate for application in KeyVault with below format (Env - nprd,prod)
  Ex:- EJF-{Env}-cert

Manual steps after the script is run

Below steps need to be repeated for each individual VM.
1)Login to the File Server VM
2)Configuration of CDS+ cert and netmapping configuration. Manual Installation required.
3)Installation for Oracle Client on Windows VM,after oracle client installaion copy of file E:\tnsnames.ora to       E:\oracle\product\19cl\network\admin\ 
4) SMTP mail configuration.

### Create PE for access from Conexus To Azure
When: Anytime after app infrastructure stage
In order to access the jumpbox and web application, private endpoints must be created in the bastion network and approved in the application subscription.
These private endpoints create IP addresses in the bastion network which can be mapped to DNS entries
Please see the following guide: https://att.sharepoint.com/sites/PC_Sol_ArchMig/SitePages/Regional-Bastion-Onboarding.aspx

### Whitelist required domains from bastion
When: Anytime after app infrastructure stage
Access from Azure to On-premise is restricted and any required access must be whitelisted.
Please see the following guide: https://att.sharepoint.com/sites/PC_Sol_ArchMig/SitePages/Regional-Bastion-Onboarding.aspx


# Apendix <a name="Apendix"></a>

## Repository Structure and Summary<a name="repositorystructure"></a>

## Known Errors<a name="KnownErrors"></a>
### VM/VMSS extension creation
Occasionally the infra pipeline may fail with an error regarding VM or VMSS extensions. If the extension fails, it must be manually removed via the portal before re-executing the pipeline. Simply navigate to the extensions menu of the VM/VMSS resource and uninstall the extension. Once uninstall completes, re-run the pipeline to install the extension again.


## Accessing Jumpbox via SSH (If applicable)<a name="AccessJumpbox"></a>
1. Get the required key from the environment key vault 
2. Get the jumpbox IP address using the bastion tool https://pc-bastion.web.att.com/
3. SSH to the jumpbox on port 80 using the username azureuser

## Changing or Reseting SSH Key
The SSH key for any VM can be reset via the Azure portal. Terraform is set to ignore changes to the admin ssh key. So if it is changed manually, executing the pipeline again will not reset the key

## Debugging steps<a name="DebuggingSteps"></a>

### Transient errors
Occassionally there may be transient errors which occur during infrastructure deployments. The best solution is to wait a bit and then rerun the required stage of the pipeline


# Resources <a name="resources"></a>

## ATT Internal Resources
- [Main Public Cloud Site](https://att.sharepoint.com/sites/PublicCloud/SitePages/What%27s-New.aspx)
- [Public Cloud Migration Sharepoint](https://att.sharepoint.com/sites/PC_Sol_ArchMig)
- [ATT Stack Overflow](https://stack.web.att.com/)
- [Public Cloud Solution Architecture tSpace](https://tspace.web.att.com/communities/service/html/communityoverview?communityUuid=a1f282ab-0c18-4627-9693-258fc338c9e3)
- [Q Rooms and helpful resources](https://stack.web.att.com/questions/18258/18263#18263)

## Public Documentation
- [Azure](https://azure.microsoft.com/en-us/get-started/)
- [Azure DevOps](https://docs.microsoft.com/en-us/azure/devops/get-started/?view=azure-devops)
- [What is Azure Pipelines](https://docs.microsoft.com/en-us/azure/devops/pipelines/get-started/what-is-azure-pipelines?view=azure-devops)
- [Terraform](https://www.terraform.io/intro/index.html)


# FAQ <a name="FAQ"></a>

## How do I update my application?
Please see the readme in your [ADO project](https://dev.azure.com/ACC-Azure-02) for steps on updating your application and best practices for pushing code changes

## How do I change my infrastructure deployed in Azure
Please see the readme in your [ADO project](https://dev.azure.com/ACC-Azure-02) for steps on updating deployed infrastructure and managing infrastructure as code

## I am experiencing issues with my application performance
Issues with application performance could stem from a number of reasons. For quickest support, please utilize the [Cloud Support Q Chat](http://launch.q.att.com/meeting/q_rooms_lg15821593534210600/Azure+Migration+Application+DSO+Cloud+Technology+Support+Chat)

## I am experiencing issues with Azure performance
If your resources or virtual machines are not behaving as expected, please follow cloud program guidelines to open a support ticket with Azure Support

## What to do if PAT_Token expires for oracle layer.
Please refer (https://wiki.web.att.com/pages/viewpage.action?spaceKey=DICA&title=DICA%20-%20Oracle%20on%20Azure)