<#
Requirements of the Windows Workload Wiki: https://dev.azure.com/ATTDevOps/ATT%20Cloud/_wiki/wikis/Optimization%20Wiki/1854/Prerequisites-and-Environment
Run-Command  3 of 4
Downloads and Installs AZ CLI.
#>

###################################################################################
# AZ CLI Installation
###################################################################################
Write-Output "Starting AZ CLI Installation $(Get-Date)"
Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -Proxy 'http://proxy.conexus.svc.local:3128' -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'; Remove-Item .\AzureCLI.msi
Write-Output "Finished AZ CLI Installation $(Get-Date)"

Start-Sleep 15
Write-Output "restarting..."
Restart-Computer -Force