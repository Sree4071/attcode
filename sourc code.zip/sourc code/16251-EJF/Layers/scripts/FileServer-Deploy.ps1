<#
Setup FileServer folder script
Authors: Jangid Subhashchand

Requirements:
VM must have MSI added as blob reader to storage account
blob must contain (fileServer.zip)zip file with the following at the root level:
EJF_FileShares - Folder location for EJF_FileShare
p8filenet - Folder location for p8filenet FileShare

Functionality:
Download the fileServer directory on Azure VM
Add permission to fileServer folder for interfaces.

Sample Run: 
./FileServer-Deploy.ps1 -Environment "nprd"

#>

param(
    [string]$Environment                                                    = $(throw "Environment is required")
 )


#####################################################################################################
#Set Variables
#####################################################################################################
Write-Output "Started FileServer-Deploy.ps1 $(Get-Date)"


$storageaccountname = "16251deploymentsstatt"
$containername = "artifacts"
$blobname = "fileServer.zip"		
$downloadPath = "E:\fileServer.zip"		

#########################################################################################
#VM Config
#########################################################################################
Write-Output "CD E: Directory"
Set-Location E:

Write-Output "Set proxy"
$env:HTTP_PROXY = "proxy.conexus.svc.local:3128"
$env:HTTPS_PROXY = "proxy.conexus.svc.local:3128"
$env:NO_PROXY = "169.254.169.254,.windows.net,.azure.net,localhost"

Write-Output "az login"
az login --identity

Write-Output "Download and extract $blobname"
az storage blob download --container-name $containername `
    --file $downloadPath `
    --name $blobname `
    --account-name $storageaccountname `
    --no-progress `
    --auth-mode login
Expand-Archive -LiteralPath $downloadPath -DestinationPath "E:\\" -force;

#Delete if folder already exists
if(Test-Path "E:\EJF_FileShares")
{
	Remove-Item "E:\EJF_FileShares" -Force -Recurse
} 
Move-Item -Path "E:\fileServer\EJF_FileShares" -Destination "E:\"

#Delete if folder already exists
if(Test-Path "E:\p8Filenet")
{
	Remove-Item "E:\p8Filenet" -Force -Recurse
} 
Move-Item -Path "E:\fileServer\p8Filenet" -Destination "E:\"



#####################################################################################################
# Add permission to vaults folder
#####################################################################################################
$folderPaths = ("E:\p8Filenet","E:\EJF_FileShares")
$mechId="m98974"
foreach ($path in $folderPaths){
    $ACL = Get-ACL -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IUSR","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("itservices\$mechId","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("NETWORK SERVICE","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    (Get-ACL -Path $path).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize
}

Write-Host "Enable SMB File Share for ECMP8"
#If Folder does not exists create
if(-not (Test-Path "E:\EJF_FileShares\ECMP8"))
{
    New-Item -ItemType directory -Path "E:\EJF_FileShares\ECMP8"
}
#If SMBShare does not exist create
IF (!(GET-SMBShare -Name "ECMP8" -ea 0))
{
    New-SmbShare -Name "ECMP8" -Path "E:\EJF_FileShares\ECMP8" -EncryptData $True
    Set-SmbPathAcl -ShareName "EJF_FileShares"
    Set-SmbPathAcl -ShareName "ECMP8"
    Grant-SmbShareAccess -Name "ECMP8" -AccountName "m98974" -AccessRight Full -Force -Confirm:$True
    Grant-SmbShareAccess -Name "ECMP8" -AccountName "m99623" -AccessRight Full -Force -Confirm:$True
    Grant-SmbShareAccess -Name "ECMP8" -AccountName "SYSTEM" -AccessRight Change -Force -Confirm:$True
    Set-SmbServerConfiguration -EncryptData $true -Force -Confirm:$True
}

Write-Host "Enable SMB File Share for FESRA"
#If Folder does not exists create
if(-not (Test-Path "E:\EJF_FileShares\FESRA"))
{
    New-Item -ItemType directory -Path "E:\EJF_FileShares\FESRA"
}
#If SMBShare does not exist create
IF (!(GET-SMBShare -Name "FESRA" -ea 0))
{
    New-SmbShare -Name "FESRA" -Path "E:\EJF_FileShares\FESRA" -EncryptData $True
    Set-SmbPathAcl -ShareName "FESRA"
    Grant-SmbShareAccess -Name "FESRA" -AccountName "m98974" -AccessRight Full -Force -Confirm:$True
    Grant-SmbShareAccess -Name "FESRA" -AccountName "SYSTEM" -AccessRight Change -Force -Confirm:$True
    Set-SmbServerConfiguration -EncryptData $true -Force -Confirm:$True
}

Write-Host "Enable SMB File Share for TEOScheduler"
#If Folder does not exists create
if(-not (Test-Path "E:\EJF_FileShares\TEOScheduler"))
{
    New-Item -ItemType directory -Path "E:\EJF_FileShares\TEOScheduler"
}
#If SMBShare does not exist create
IF (!(GET-SMBShare -Name "TEOScheduler" -ea 0))
{
    New-SmbShare -Name "TEOScheduler" -Path "E:\EJF_FileShares\TEOScheduler" -EncryptData $True
    Set-SmbPathAcl -ShareName "TEOScheduler"
    Grant-SmbShareAccess -Name "TEOScheduler" -AccountName "m98974" -AccessRight Full -Force -Confirm:$True
    Grant-SmbShareAccess -Name "TEOScheduler" -AccountName "SYSTEM" -AccessRight Change -Force -Confirm:$True
    Set-SmbServerConfiguration -EncryptData $true -Force -Confirm:$True
}

Write-Host "Enable SMB File Share for vaults"
#If Folder does not exists create
if(-not (Test-Path "E:\vaults"))
{
    New-Item -ItemType directory -Path "E:\vaults"
}
#If SMBShare does not exist create
IF (!(GET-SMBShare -Name "vaults" -ea 0))
{
    New-SmbShare -Name "vaults" -Path "E:\vaults" -EncryptData $True
    Set-SmbPathAcl -ShareName "vaults"
    Grant-SmbShareAccess -Name "vaults" -AccountName "m98974" -AccessRight Read -Force -Confirm:$True
    Set-SmbServerConfiguration -EncryptData $true -Force -Confirm:$True
}

$scriptLogsDirectory = "C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status"
$logsStorageAccountName = "ejf${Environment}stdgatt001"

Write-Output "uploading logs"
#####################################################################################################
# Upload Logs to Storage Account
#####################################################################################################
# Logs are stored as xx.status in C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status directory
Set-Location $scriptLogsDirectory
$latestLogs = Get-ChildItem | Sort-Object LastWriteTime | Select-Object -last 1
if (Test-Path -Path $latestLogs) {
    Write-Host  "$latestLogs exists, logs will be uploaded to storage account"
    $logFile = "$(hostname)-fileserver-logs-$(Get-Date -Format "MM-dd-yyyy-Hms").txt"
    [IO.File]::ReadAllText($scriptLogsDirectory+"\"+$latestLogs) -replace '\\n',"`r`n" | Out-File $logFile
    $logsContainerName = "${Environment}-logs-$(Get-Date -Format "MM-dd-yy")"
    az storage container create --name $logsContainerName `
        --account-name $logsStorageAccountName `
        --auth-mode login
    az storage blob upload --container-name $logsContainerName `
        --file ./$logFile `
        --name $logFile `
        --account-name $logsStorageAccountName `
        --auth-mode login --no-progress
}

Write-Host "Script executed!"