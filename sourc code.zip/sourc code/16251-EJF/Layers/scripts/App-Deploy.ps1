<#
EJF Installation script
Authors: Jangid Subhashchand

Requirements:
VM must have MSI added as blob reader to storage account
blob must contain (webs.zip)zip file with the following at the root level:
EJFR2App and HD app related binaries.


Functionality:
Configure EJF Notification Service.
Add permission to Webs folder for application hosting.
App binaries which will host the application.
Download PFX certificate.
Install ABC PDF Software.
Import and configure Task Schedule Batch Jobs.
Install Toad for oracle and related dependencies.

Sample Run: 
./App-Deploy.ps1 -Environment "nprd" -KeyVaultName "ejf-eastus2-nprd-kv-02" -EJFHostname "ejf-test.az.3pc.att.com" -CertificateName "nprdcert"

#>

param(
    [string]$Environment                                                    = $(throw "Environment is required"),
    [string]$EJFHostname                                                   = $(throw "EJFHostname is required")
)


#####################################################################################################
#Set Variables
#####################################################################################################
Write-Output "Started App-Deploy.ps1 $(Get-Date)"

Import-Module WebAdministration
#$TRUE = "false"
#Declaring variables
$AppPhysicalPathEJF = "E:\webs\EJFR2App\DownNotice"    
$AppPhysicalPathEJFR2 = "E:\webs\EJFR2App\EJF"
$AppPhysicalPathHD = "E:\webs\HD"
$VirtualDirectoryPhysicalPath = "E:\vaults"
$CertFolderPath = "E:\EJFCert"    
$SMTPMTAHostname = "mta.${Environment}.16251.az.3pc.att.com"

$KeyVaultName = "ejf-eastus2-${Environment}-kv-02"
$CertificateName = "ejf-${Environment}-cert"
$certPassword = 'certpassword'
$pfxFilePath = "E:\EJFCert\${EJFHostname}.pfx"
$pemFilePath = "E:\${EJFHostname}.pem"
$password = ''
$EJFConnectionString = 'EJFConnectionString'
$EJFHDConnectionString = 'EJFHDConnectionString'
$mechIdPassword = 'mechIdPassword'
$tnsdbEntry = 'tnsDbEntry'
$ABCpdfLicense = 'ABCpdfLicense'
$pathEJFNotifyEngine="E:\webs\EJFR2App\NotificationEngine_Release_64Bit\EJF.Notifications.Engine.exe.config"
$pathEJFHDWebConfig="E:\webs\HD\web.config"
$tnsPath = "E:\tnsnames.ora"

$AppPoolNameEJF="EJF"
$AppsiteNameEJF= "EJF"
$AppPoolNameEJFR2="EJFR2"
$AppsiteNameEJFR2= "EJFR2"
$AppsiteNameHD= "HD"
$FWADnsName = $EJFHostname

$storageaccountname = "16251deploymentsstatt"
$containername = "artifacts"
$blobname = "webs.zip"
$OpenSSLBlobName = "OpenSSL-Win32.zip"	
$fileName = $blobname.Split(".")[0]			
$downloadPath = "E:\webs.zip"	
$downloadPathOpenSSL = "E:\OpenSSL-Win32.zip"	

$scriptLogsDirectory = "C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\*\Status"
$logsStorageAccountName = "ejf${Environment}stdgatt001"

#########################################################################################
#VM Config
#########################################################################################
Write-Output "Setting VM Time Zone To CST"
Set-TimeZone -Id "Central Standard Time"
Write-Output "VM Time Zone Set To CST"

Write-Output "CD E: Directory"
Set-Location E:

Write-Output "Set proxy"
$env:HTTP_PROXY = "proxy.conexus.svc.local:3128"
$env:HTTPS_PROXY = "proxy.conexus.svc.local:3128"
$env:NO_PROXY = "169.254.169.254,.windows.net,.azure.net,localhost"


Write-Output "az login"
az login --identity

$servicename = "EJFNotService"
Write-Output "Delete EJFNotService if exists"
if (Get-Service $servicename -ErrorAction SilentlyContinue)
{
    SC.exe STOP $servicename
    SC.exe DELETE $servicename
}

$FileNetP8Process = "FileNetP8"
Write-Output "Stop FileNetP8 Process if exists"
if (Get-Process $FileNetP8Process -ErrorAction SilentlyContinue)
{
    Stop-Process -Name $FileNetP8Process -Force
}

$FTP_CTSTickets2012Process = "FTP_CTSTickets2012"
Write-Output "Stop FTP_CTSTickets2012 Process if exists"
if (Get-Process $FTP_CTSTickets2012Process -ErrorAction SilentlyContinue)
{
    Stop-Process -Name $FTP_CTSTickets2012Process -Force
}

$MyLoginsProcess = "MyLogins"
Write-Output "Stop MyLogins Process if exists"
if (Get-Process $MyLoginsProcess -ErrorAction SilentlyContinue)
{
    Stop-Process -Name $MyLoginsProcess -Force
}

Write-Output "Download and extract $blobname"
az storage blob download --container-name $containername `
    --file $downloadPath `
    --name $blobname `
    --account-name $storageaccountname `
    --no-progress `
    --auth-mode login
Expand-Archive -LiteralPath $downloadPath -DestinationPath "E:\\" -force;


Write-Output "Download and extract $OpenSSLBlobName"		#
az storage blob download --container-name $containername `
    --file $downloadPathOpenSSL `
    --name $OpenSSLBlobName `
    --account-name $storageaccountname `
    --no-progress `
    --auth-mode login
Expand-Archive -LiteralPath $downloadPathOpenSSL -DestinationPath "E:\\" -force;


#####################################################################################################
# Add permission to Webs folder
#####################################################################################################
$folderPaths = ("E:\webs")
$mechId="m98974"
foreach ($path in $folderPaths){
    $ACL = Get-ACL -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IUSR","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("itservices\$mechId","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("NETWORK SERVICE","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    (Get-ACL -Path $path).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize
}

# Remove the default website
if (Test-Path "IIS:\sites\Default Web Site") {
    Write-Output "Remove the default website"
    Remove-WebSite -Name "Default Web Site"
}

#Fetching connection string for EJFR2 App
$EJFDBConnectionString = (az keyvault secret show --name $EJFConnectionString --vault-name $KeyVaultName --query value).Trim('"')

Write-Host "Configure EJF Notification WebConfig"
# Read the existing file
[xml]$xmlDoc = Get-Content $pathEJFNotifyEngine
# update NotificationBuilder settings
$xmlDoc.configuration.NotificationBuilder.conectionstring = $EJFDBConnectionString
$xmlDoc.configuration.NotificationBuilder.mailserver = $SMTPMTAHostname

# update CustomEmailBuilder settings
$xmlDoc.configuration.CustomEmailBuilder.conectionstring = $EJFDBConnectionString
$xmlDoc.configuration.CustomEmailBuilder.mailserver = $SMTPMTAHostname

# update NotificationEmailDeliveryAgent settings
$xmlDoc.configuration.NotificationEmailDeliveryAgent.conectionstring = $EJFDBConnectionString
$xmlDoc.configuration.NotificationEmailDeliveryAgent.mailserver = $SMTPMTAHostname

# update CustomEmailDeliveryAgent settings
$xmlDoc.configuration.CustomEmailDeliveryAgent.conectionstring = $EJFDBConnectionString
$xmlDoc.configuration.CustomEmailDeliveryAgent.mailserver = $SMTPMTAHostname

# update config file
$xmlDoc.Save($pathEJFNotifyEngine)
Write-Host "Configure EJF Notification WebConfig updated"

Write-Host "Configure EJF HD SMTP in WebConfig"
# Read the existing file
[xml]$xmlDoc = Get-Content $pathEJFHDWebConfig
# update mail settings
$xmlDoc.configuration.'system.net'.mailSettings.smtp.network.host  = $SMTPMTAHostname
# update config file
$xmlDoc.Save($pathEJFHDWebConfig)
Write-Host "Configure EJF HD SMTP in WebConfig updated"


# Installing IIS roles and features
#Install-WindowsFeature -ConfigurationFilePath "E:\EJF-IIS-DeploymentConfigTemplate.xml"
#creating app pool 
	$mechIdPassword= (az keyvault secret show --name $mechIdPassword --vault-name $KeyVaultName --query value).Trim('"')
	$tnsDbEntry= (az keyvault secret show --name $tnsdbEntry --vault-name $KeyVaultName --query value).Trim('"')
	$ABCpdfLicense=	(az keyvault secret show --name $ABCpdfLicense --vault-name $KeyVaultName --query value).Trim('"')
 # Adding entry in tnsnames.ora
if (Test-Path $tnsPath) {
    Remove-Item $tnsPath -Force -Recurse
}
    Add-Content -Path $tnsPath -Value (Get-Content -Path "E:\mm243d\tnsnames.ora")
    Add-Content -Path $tnsPath -Value $tnsDbEntry

if(Test-Path IIS:\AppPools\$AppPoolNameEJF)
{
	"AppPoolEJF is already there"
}
else
{
	"AppPoolEJF is not present"
	"Creating new AppPool"
	New-Item -Path IIS:\AppPools\$AppPoolNameEJF
	Set-ItemProperty -Path IIS:\AppPools\$AppPoolNameEJF -Name "processModel.loadUserProfile" -Value "True"
}
	Set-ItemProperty -Path IIS:\AppPools\$AppPoolNameEJF -Name processModel -value @{userName="itservices\$mechId";password=$mechIdPassword;identitytype=3}

if(Test-Path IIS:\AppPools\$AppPoolNameEJFR2)
{
	"AppPoolEJFR2 is already there"
}
else
{
	"AppPoolEJFR2 is not present"
	"Creating new AppPool"
	New-Item -Path IIS:\AppPools\$AppPoolNameEJFR2
	Set-ItemProperty -Path IIS:\AppPools\$AppPoolNameEJFR2 -Name "processModel.loadUserProfile" -Value "True"
}
	Set-ItemProperty -Path IIS:\AppPools\$AppPoolNameEJFR2 -Name processModel -value @{userName="itservices\$mechId";password=$mechIdPassword;identitytype=3}


# creating website 
if(Test-Path IIS:\sites\$AppsiteNameEJF)
{
	"site is already there"
}
else
{
	"site is not present"
	"Creating new site"
	New-Website -Name $AppsiteNameEJF -HostHeader $FWADnsName -PhysicalPath $AppPhysicalPathEJF -ApplicationPool $AppPoolNameEJF
    
    # Create the Applications
    New-WebApplication -Site $AppsiteNameEJF -Name EJFR2 -PhysicalPath $AppPhysicalPathEJFR2 -ApplicationPool $AppPoolNameEJFR2
    New-WebApplication -Site $AppsiteNameEJF -Name HD -PhysicalPath $AppPhysicalPathHD -ApplicationPool $AppPoolNameEJF

    # Create Virtual Directory
    New-WebVirtualDirectory -Site $AppsiteNameEJF -Name vaults -PhysicalPath $VirtualDirectoryPhysicalPath

}

#Importing certificate and binding with application site
 if (Test-Path $CertFolderPath) {
    Remove-Item $CertFolderPath -Force -Recurse
}
 	"Application folder is not present"
 	"creating a folder "
    Write-Output "Create $CertFolderPath and $pfxFilePath"
    mkdir $CertFolderPath
	#downloading SSL certificate
	Write-Output "downloading SSL certificate $CertificateName"
	az keyvault secret download --file $pfxFilePath --encoding base64 --name $CertificateName --vault-name $KeyVaultName
	$password = (az keyvault secret show --name $certPassword --vault-name $KeyVaultName --query value).Trim('"')

	Write-Output "Import into certCollection"
	$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection  	
	$certCollection.Import($pfxFilePath, $null, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)  
	$protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $password)  
		
	[System.IO.File]::WriteAllBytes($pfxFilePath, $protectedCertificateBytes) 

	Write-Output "Import with certutil"
	certutil -f -p ${password} -importpfx ${pfxFilePath} 
	Write-Output "Convert pfx to pem"
	###Connect Direct Installation
	E:\OpenSSL-Win32\openssl pkcs12 -in $pfxFilePath -out $pemFilePath -nodes -passin  pass:$password


# 	#Binding certificate  with app  
if (!(Get-WebBinding -Name "$AppsiteNameEJF" -Protocol "https")) {
    Write-Output "Add HTTPS binding"
    New-WebBinding -name $AppsiteNameEJF -Protocol https  -HostHeader $FWADnsName -Port 443 -SslFlags 1
    Write-Output "Remove HTTP binding"
    Remove-WebBinding -name $AppsiteNameEJF -Protocol http -HostHeader $FWADnsName
}

 	$ejfcert = (Get-ChildItem cert:\LocalMachine\My | where-object { $_.DnsNameList -eq $EJFHostname }).Thumbprint

     $httpsBinding = Get-WebBinding -Name "$AppsitenameEJF" -Protocol "https"
     $httpsBinding.AddSslCertificate($ejfcert, "my")
 	#getting certification password
	$EJFHDDBConnectionString = (az keyvault secret show --name $EJFHDConnectionString --vault-name $KeyVaultName --query value).Trim('"')

	set-WebConfigurationproperty -pspath "IIS:\Sites\EJF\EJFR2" -filter "connectionStrings/add[@name='EJFConnectionString']" -name 'connectionString' -value $EJFDBConnectionString
    set-WebConfigurationproperty -pspath "IIS:\Sites\EJF\HD" -filter "connectionStrings/add[@name='DatabaseCODMS1']" -name 'connectionString' -value $EJFHDDBConnectionString



Write-Host "ABC PDF Installation started"
cd E:\mm243d\source\ABCpdf9
& '.\Installer.msi' TARGETDIR=`"E:\Program Files\WebSupergoo\ABCpdf .NET 9.1 x64`" /qb
$ABCpdfPath ='E:\Program Files\WebSupergoo\ABCpdf .NET 9.1 x64\ABCpdf.dll'
[Reflection.Assembly]::LoadFrom($ABCpdfPath)
if ([WebSupergoo.ABCpdf9.XSettings]::InstallSystemLicense(${ABCpdfLicense}))
{
    "License Successfully Installed"
}
else
{
    "License Installation Failed"
}  

Write-Host "ABC PDF Installation completed"

Write-Host "If not exists Configure EJF Notification Service"
 if(-not (Test-Path "e:\Oraclex64"))
 {
	cd E:\mm243d\source\odac\ODAC1120320Xcopy_x64
	& ".\install.bat" odp.net4 e:\Oraclex64 odac11

	Write-Host "Configure Oraclex64 folder for EJF Notification Service"
 }

Write-Host "If not exists Create EJF Notification Service"
if (-not (Get-Service $servicename -ErrorAction SilentlyContinue))
{
	cd E:\webs\EJFR2App\NotificationEngine_Release_64Bit
	& ".\InstallUtil.exe" ".\EJF.Notifications.Engine.exe"
	Set-Service -Name EJFNotService -StartupType Automatic
	Start-Service -Name EJFNotService
	Write-Host "Configure EJF Notification Service Completed"
}

Write-Host "Configure Task Schedular Jobs"
$path="E:\mm243d\Task Scheduler\TaskSchedulerEJF\"
Get-ChildItem $path -Filter "*.xml"| foreach {
$task_conf=Get-Item -Path $_.FullName
$taskname=$task_conf.Name.Replace('.xml', '')
$task_xml=$task_conf.FullName
Register-ScheduledTask -xml (Get-Content $task_xml | Out-String) -TaskName $taskname -TaskPath "\Microsoft" -User "itservices\$mechId" -Password $mechIdPassword -Force
}

Start-IISSite -Name $AppsiteNameEJF

Write-Output "Installing msxml"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\Msxml\msxml.msi" /q INSTALLDIR="E:\Program Files\Quest Software"' -wait

Write-Output "Installing Toad for Oracle 12.1 64bit"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\toadmsi\Toad_Standalone_64\12_1_0_22\Toad for Oracle 12.1 64bit.msi" /q /l*v "E:\Toad for Oracle 12.1 64bit.msi.log" INSTALLDIR="E:\Program Files\Quest Software\Toad for Oracle 12.1\"' -wait
regedit /s "E:\mm243d\source\toad\toadmsi\Toad_Standalone_64\12_1_0_22\QuestKey.reg"

Write-Output "Installing Quest SQL Optimizer for Oracle 64-bit 8.8.1.2667"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\toadmsi\QuestSQLOptimizer_Oracle_64\8_8_1_2667\QuestSQLOptimizerForOracle_8_8_1_2667_64bit.msi" /q /l*v "E:\QuestSQLOptimizerForOracle_8_8_1_2667_64bit.msi.log" INSTALLDIR="E:\Program Files\Quest Software\Quest SQL Optimizer for Oracle\"' -wait

Write-Output "Installing Benchmark Factory for Databases 64-bit 6.9.2.621"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\toadmsi\Benchmark_Factory_64\6_9_2_621\BenchmarkFactory_6_9_2_621_64bit.msi" /q /l*v "E:\BenchmarkFactory_6_9_2_621_64bit.msi.log" INSTALLDIR="E:\Program Files\Quest Software\Benchmark Factory for Databases"' -wait

Write-Output "Installing Spotlight on Oracle 64-bit 9.6.0.854"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\toadmsi\Performance_Diagnostics_(Spotlight_On_Oracle)_64\9_6_0_854\Spotlight on Oracle 9.6.0.854 x64.msi" /q /l*v "E:\Spotlight on Oracle 9.6.0.854 x64.msi.log" INSTALLDIR="E:\Program Files\Quest Software\Spotlight on Oracle 9.6\"' -wait

Write-Output "Installing Toad Data Modeler 5.1.1.12"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\toadmsi\Toad_Data_Modeler\5_1_1_12\ToadDataModeler_5.1.1.12.msi" /q /l*v "E:\ToadDataModeler_5.1.1.12.msi.log" /q INSTALLDIR="E:\Program Files\Quest Software\Toad Data Modeler 5.1" ALLUSERS=2 ADDLOCAL=Complete,XPMANIFEST,SHORTCUTUNINSTALL,SHORTCUTDESKTOP,SHORTCUTSTARTMENU,SUPPORTDATABASES,UNIVERSAL_DATABASE,ORACLE_9,ORACLE_10G,ORACLE_11G_R1,ORACLE_11G_R2,ORACLE_12,ORACLE,ORACLE_11G' -wait

Write-Output "Installing Backup Reporter for Oracle 1.6.1.22"
Start-Process msiexec.exe -ArgumentList '/i "E:\mm243d\source\toad\toadmsi\Backup_Reporter\1_6_1_22\BackupReporter_1.6.1.22.msi" /q /l*v "E:\BackupReporter_1.6.1.22.msi.log" INSTALLDIR="E:\Program Files\Quest Software\Backup Reporter 1.6\"' -wait

Write-Host "Script executed!"

Write-Output "uploading logs"
#####################################################################################################
# Upload Logs to Storage Account
#####################################################################################################
# Logs are stored as xx.status in C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status directory
Set-Location $scriptLogsDirectory
$latestLogs = Get-ChildItem | Sort-Object LastWriteTime | Select-Object -last 1
if (Test-Path -Path $latestLogs) {
    Write-Host  "$latestLogs exists, logs will be uploaded to storage account"
    $logFile = "$(hostname)-App-Deploy-logs-$(Get-Date -Format "MM-dd-yyyy-Hms").txt"
    [IO.File]::ReadAllText($scriptLogsDirectory+"\"+$latestLogs) -replace '\\n',"`r`n" | Out-File $logFile
    $logsContainerName = "${Environment}-logs-$(Get-Date -Format "MM-dd-yy")"
    az storage container create --name $logsContainerName `
        --account-name $logsStorageAccountName `
        --auth-mode login
    az storage blob upload --container-name $logsContainerName `
        --file ./$logFile `
        --name $logFile `
        --account-name $logsStorageAccountName `
        --auth-mode login --no-progress
}