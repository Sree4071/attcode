<#
Setup mm342 directory script
Authors: Jangid Subhashchand

Requirements:
VM must have MSI added as blob reader to storage account
blob must contain (mm243d.zip)zip file with the following at the root level:
EJFUSER-Schema - Containing EJFUserSchema
source - Containing required software msi installers at location 
        (mm243d\source\ABCpdf9,mm243d\source,mm243d\source\odac,mm243d\source\toad\toadmsi,
         mm243d\source\toad\Msxml)
Task Scheduler - Containing Task Schedular Jobs.

Functionality:
Download the mm243d directory on Azure VM
Add permission to dir folder for interfaces.

Sample Run: 
./Dir-Deploy.ps1 -Environment "nprd"

#>

param(
    [string]$Environment                                                    = $(throw "Environment is required")
)


#####################################################################################################
#Set Variables
#####################################################################################################
Write-Output "Started Dir-Deploy.ps1 $(Get-Date)"


$storageaccountname = "16251deploymentsstatt"
$containername = "artifacts"
$blobname = "mm243d.zip"		
$downloadPath = "E:\mm243d.zip"	

#########################################################################################
#VM Config
#########################################################################################
Write-Output "CD E: Directory"
Set-Location E:

Write-Output "Set proxy"
$env:HTTP_PROXY = "proxy.conexus.svc.local:3128"
$env:HTTPS_PROXY = "proxy.conexus.svc.local:3128"
$env:NO_PROXY = "169.254.169.254,.windows.net,.azure.net,localhost"

Write-Output "az login"
az login --identity

Write-Output "Download and extract $blobname"
az storage blob download --container-name $containername `
    --file $downloadPath `
    --name $blobname `
    --account-name $storageaccountname `
    --no-progress `
    --auth-mode login
Expand-Archive -LiteralPath $downloadPath -DestinationPath "E:\\" -force;


#####################################################################################################
# Add permission to vaults folder
#####################################################################################################
$folderPaths = ("E:\mm243d")
$mechId="m98974"
foreach ($path in $folderPaths){
    $ACL = Get-ACL -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IUSR","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("itservices\$mechId","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL.SetAccessRule($AccessRule)
    $ACL | Set-Acl -Path $path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("NETWORK SERVICE","FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $ACL | Set-Acl -Path $path
    (Get-ACL -Path $path).Access | Format-Table IdentityReference,FileSystemRights,AccessControlType,IsInherited,InheritanceFlags -AutoSize
}

$scriptLogsDirectory = "C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status"
$logsStorageAccountName = "ejf${Environment}stdgatt001"

Write-Output "uploading logs"
#####################################################################################################
# Upload Logs to Storage Account
#####################################################################################################
# Logs are stored as xx.status in C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status directory
Set-Location $scriptLogsDirectory
$latestLogs = Get-ChildItem | Sort-Object LastWriteTime | Select-Object -last 1
if (Test-Path -Path $latestLogs) {
    Write-Host  "$latestLogs exists, logs will be uploaded to storage account"
    $logFile = "$(hostname)-dirsetup-logs-$(Get-Date -Format "MM-dd-yyyy-Hms").txt"
    [IO.File]::ReadAllText($scriptLogsDirectory+"\"+$latestLogs) -replace '\\n',"`r`n" | Out-File $logFile
    $logsContainerName = "${Environment}-logs-$(Get-Date -Format "MM-dd-yy")"
    az storage container create --name $logsContainerName `
        --account-name $logsStorageAccountName `
        --auth-mode login
    az storage blob upload --container-name $logsContainerName `
        --file ./$logFile `
        --name $logFile `
        --account-name $logsStorageAccountName `
        --auth-mode login --no-progress
}

Write-Host "Script executed!"