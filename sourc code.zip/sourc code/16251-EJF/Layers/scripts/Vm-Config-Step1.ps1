<#
Requirements of the Windows Workload Wiki: https://dev.azure.com/ATTDevOps/ATT%20Cloud/_wiki/wikis/Optimization%20Wiki/1854/Prerequisites-and-Environment
Run-Command 1 of  4
Removes the CD and floppy drives
Sets the pagefile to the C drive so that the D: drive can removed in a later step
Sets proxy
#>

Write-Output "Starting Remove CD and Floppy $(Get-Date)"

Write-Output "Remove CD and Floppy drive assignments"
reg add HKLM\System\CurrentControlSet\Services\cdrom /t REG_DWORD /v "Start" /d 4 /f
reg add HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\flpydisk /t REG_DWORD /v "Start" /d 4 /f

Write-Output "Remove pagefile"
Get-WmiObject win32_pagefilesetting
$pf=Get-WmiObject win32_pagefilesetting
$pf.Delete()

Write-Output "Set pagefile to C:\pagefile.sys and restart"
wmic pagefileset create name="C:\pagefile.sys"

Write-Output "Set proxy"
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyServer -Value "proxy.conexus.svc.local:3128"
Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyEnable -Value 1

Write-Output "restarting..."
Restart-Computer -Force