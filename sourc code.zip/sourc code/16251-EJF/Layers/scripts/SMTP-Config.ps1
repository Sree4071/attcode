#####################################################################################
# PowerShell Script to Install and Configure SMTP server / MTA on Windows 2016
#							
# Prerequisites:
# Upload the certificate for the MTA in Azure Keyvault [ this is required to setup TLS ]	
#							
#####################################################################################
param(
      [string]$Environment = $(throw "Environment is required")
)

#####################################################################################################
#Set Variables
#####################################################################################################
Write-Output "Started SMTP-Config.ps1 $(Get-Date)"

$Environment = $Environment.Trim("`"")

$KeyVaultName = "ejf-eastus2-${Environment}-kv-02"

$maildomain = "mta.${Environment}.16251.az.3pc.att.com"
$aliasEmailDomainName = "$env:computername.az.3pc.att.com"

$certificateSecretName = "mta-$Environment-01-16251-az-3pc-att-com"
$certPasswordSecretName = "mta-$Environment-01-16251-PW"

$pfxFolderPath = "E:\EJFSMTPCert"
$pfxFilePath = "${pfxFolderPath}\${certificateSecretName}.pfx"

$scriptLogsDirectory = "C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status"
$logsStorageAccountName = "ejf${Environment}stdgatt001"

#####################################################################################################
#VM Config
#####################################################################################################
Write-Output "CD E: Directory"
Set-Location E:

Write-Output "Set proxy"
$env:HTTP_PROXY = "proxy.conexus.svc.local:3128"
$env:HTTPS_PROXY = "proxy.conexus.svc.local:3128"
$env:NO_PROXY = "169.254.169.254,.windows.net,.azure.net,localhost"

Write-Output "az login"
az login --identity

#####################################################################################################
#Download Certificate
#####################################################################################################
if (Test-Path $pfxFolderPath) {
      Remove-Item $pfxFolderPath -Force -Recurse
}
Write-Output "Create $pfxFolderPath and $pfxFilePath"
mkdir $pfxFolderPath

Write-Output "downloading SSL certificate $certificateSecretName"
az keyvault secret download --file $pfxFilePath --encoding base64 --name $certificateSecretName --vault-name $KeyVaultName
$password = (az keyvault secret show --name $certPasswordSecretName --vault-name $KeyVaultName --query value).Trim('"')
Import-PfxCertificate -FilePath $pfxFilePath -CertStoreLocation Cert:\LocalMachine\My -Password (ConvertTo-SecureString -String $password -AsPlainText -Force) -Exportable

#####################################################################################################
#Install SMPT Features and start service
#####################################################################################################
Write-Output "Import-Module servermanager and install windows features"
Import-Module servermanager
Install-WindowsFeature -Name SMTP-Server -IncludeAllSubFeature -IncludeManagementTools
Install-WindowsFeature -Name Web-WMI, Web-Scripting-Tools

Write-Output "Start-Service "SMTPSVC""
Start-Service "SMTPSVC"
Set-Service "SMTPSVC" -StartupType Automatic

#####################################################################################################
#Update SMTP port Binding Port to 25
#####################################################################################################
Write-Output "Update SMTP port Binding Port to 25"
$IISSmtpServerSetting = (Get-WmiObject -namespace root\microsoftiisv2 -class IISSmtpServerSetting)
$ServerBindings = $IISSmtpServerSetting.ServerBindings
foreach ($Binding in $ServerBindings) {
      $Binding.Port = "25"
} 
$IISSmtpServerSetting.ServerBindings = $ServerBindings
$IISSmtpServerSetting.Put()

#####################################################################################################
#Configure Virtual SMPTP Server
#####################################################################################################
Write-Output "Configure Virtual SMPTP Server"
$virtualSMTPServer = Get-WmiObject IISSmtpServerSetting -namespace "ROOT\MicrosoftIISv2" | Where-Object { $_.name -like "SmtpSVC/1" }
$virtualSMTPServer.BadMailDirectory = 'E:\mailroot\Badmail'
$virtualSMTPServer.QueueDirectory = 'E:\mailroot\Queue'
$virtualSMTPServer.PickupDirectory = 'E:\mailroot\Pickup'
$virtualSMTPServer.DropDirectory = 'E:\mailroot\Drop'
$virtualSMTPServer.AllowAnonymous = 'true'
$virtualSMTPServer.DefaultDomain = "$maildomain"
$virtualSMTPServer.FullyQualifiedDomainName = "$maildomain"
$virtualSMTPServer.DoMasquerade = 'True'
$virtualSMTPServer.MasqueradeDomain = "$maildomain"
$virtualSMTPServer.RouteAction = '4'
$virtualSMTPServer.SmartHost = 'smtptls.it.att.com'
$virtualSMTPServer.LogExtFileFlags = '1345252'
$virtualSMTPServer.LogExtFileComputerName = 'True'
$virtualSMTPServer.LogExtFileTime = 'False'
$virtualSMTPServer.LogType = '1'
$virtualSMTPServer.RelayForAuth = '-1'
$virtualSMTPServer.SmartHostType = '2'
$virtualSMTPServer.MaxBatchedMessages = 0
$virtualSMTPServer.AccessSsl = 'True'
$virtualSMTPServer.relayIPList = @(24,0,0,128,32,0,0,128,60,0,0,128,68,0,0,128,1,0,0,0,76,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,2,0,0,0,1,0,0,0,4,0,0,0,0,0,0,0,76,0,0,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255)
$virtualSMTPServer.Put()


Write-Output "Create incoming SMTP domain"
$smtpDomains = [wmiclass]'root\MicrosoftIISv2:IIsSmtpDomain'
$newSMTPDomain = $smtpDomains.CreateInstance()
$newSMTPDomain.Name = "SmtpSvc/1/Domain/$aliasEmailDomainName"
$newSMTPDomain.Put()

Write-Output "Configure new incoming SMTP domain setting"
$smtpDomainSettings = [wmiclass]'root\MicrosoftIISv2:IIsSmtpDomainSetting'
$newSMTPDomainSetting = $smtpDomainSettings.CreateInstance()
$newSMTPDomainSetting.RouteAction = 16
             
Write-Output "Map the configured setting to the created domain"
$newSMTPDomainSetting.Name = "SmtpSvc/1/Domain/$aliasEmailDomainName"
$newSMTPDomainSetting.Put()


Write-Output "Finished SMTP-Config.ps1 $(Get-Date)"
#####################################################################################################
# Upload Logs to Storage Account
#####################################################################################################
# Logs are stored as xx.status in C:\Packages\Plugins\Microsoft.CPlat.Core.RunCommandWindows\1.1.8\Status directory
Set-Location $scriptLogsDirectory
$latestLogs = Get-ChildItem | Sort-Object LastWriteTime | Select-Object -last 1
if (Test-Path -Path $latestLogs) {
    Write-Host  "$latestLogs exists, logs will be uploaded to storage account"
    $logFile = "$(hostname)-winscpsetup-logs-$(Get-Date -Format "MM-dd-yyyy-Hms").txt"
    [IO.File]::ReadAllText($scriptLogsDirectory+"\"+$latestLogs) -replace '\\n',"`r`n" | Out-File $logFile
    $logsContainerName = "${Environment}-logs-$(Get-Date -Format "MM-dd-yy")"
    az storage container create --name $logsContainerName `
        --account-name $logsStorageAccountName `
        --auth-mode login
    az storage blob upload --container-name $logsContainerName `
        --file ./$logFile `
        --name $logFile `
        --account-name $logsStorageAccountName `
        --auth-mode login --no-progress
}