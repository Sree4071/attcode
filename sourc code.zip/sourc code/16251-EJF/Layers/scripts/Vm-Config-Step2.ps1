<#
Requirements of the Windows Workload Wiki: https://dev.azure.com/ATTDevOps/ATT%20Cloud/_wiki/wikis/Optimization%20Wiki/1854/Prerequisites-and-Environment
Run-Command  2 of 4
Formats and sizes disks
Removes pagefile and sets to Y
#>
Write-Output "Starting Disk Setup $(Get-Date)"

Write-Output "Initialize any raw partitions"
Get-Disk | Where-Object PartitionStyle -Eq 'RAW' | Initialize-Disk

Write-Output "Set Disk 1 to Y partition"
Get-Partition -DiskNumber 1 | Where-Object {$_.driveletter -ne 'Y'}  | Set-Partition -NewDriveLetter Y 

Write-Output "Set C Partition to max size"
$size = Get-PartitionSupportedSize -DriveLetter C
Get-Partition -DriveLetter C | Where-Object {$_.size -ne $size.SizeMax } | Resize-Partition -Size $size.SizeMax

Write-Output "Remove Existing Partitions"
Remove-Partition -DriveLetter D,E,F,G,H,I,T,X -ErrorAction SilentlyContinue -Confirm:$false

Write-Output "Set Disk 2-9 partitions to max size"
New-Partition -DiskNumber 2 -DriveLetter D -UseMaximumSize
New-Partition -DiskNumber 3 -DriveLetter E -UseMaximumSize
New-Partition -DiskNumber 4 -DriveLetter F -UseMaximumSize -ErrorAction SilentlyContinue
New-Partition -DiskNumber 5 -DriveLetter G -UseMaximumSize -ErrorAction SilentlyContinue
New-Partition -DiskNumber 6 -DriveLetter H -UseMaximumSize -ErrorAction SilentlyContinue
New-Partition -DiskNumber 7 -DriveLetter I -UseMaximumSize -ErrorAction SilentlyContinue
New-Partition -DiskNumber 8 -DriveLetter T -UseMaximumSize -ErrorAction SilentlyContinue
New-Partition -DiskNumber 9 -DriveLetter X -UseMaximumSize -ErrorAction SilentlyContinue

Write-Output "Format partitions"
Format-Volume -DriveLetter D,E -FileSystem NTFS -Confirm:$false
Format-Volume -DriveLetter F,G,H,I,T,X -FileSystem NTFS -ErrorAction SilentlyContinue -Confirm:$false

Write-Output "List Filesystem"
Get-PSDrive -PSProvider 'FileSystem'

Write-Output "Remove pagefile"
Get-WmiObject win32_pagefilesetting
$pf=Get-WmiObject win32_pagefilesetting
$pf.Delete()

Write-Output "Set pagefile to Y:\ and restart"
wmic pagefileset create name="Y:\pagefile.sys"


Write-Output "restarting..."
Restart-Computer -Force