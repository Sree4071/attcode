<#
Requirements of the Windows Workload Wiki: https://dev.azure.com/ATTDevOps/ATT%20Cloud/_wiki/wikis/Optimization%20Wiki/1854/Prerequisites-and-Environment
Run-Command  4 of 4
Runs CCM setup. After CCM is executed, it takes 60 minutes for the VM to show up in SCCM tool. http://sccmtools.web.att.com/
This appears to be managed via a background process, so if the VM is restarted prior to this process finishing it may not show up in the tool as expected
#>

###################################################################################
# CCM Setup
###################################################################################
Write-Output "Starting Run-CCMSetup $(Get-Date)"
C:\Windows\Temp\ccmsetup\Client\CCMSetup.exe /noservice /MP:ACE2PSC07310001.itservices.sbc.com SMSSITECODE=N00 SMSSLP=ACE2PSC07310001.itservices.sbc.com | Out-Null
#sleep to allow SCCM to do its thing
Start-Sleep 30
Write-Output "Finished Run-CCMSetup $(Get-Date)"